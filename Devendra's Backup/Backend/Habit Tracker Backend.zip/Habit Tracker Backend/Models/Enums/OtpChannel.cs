﻿namespace Habit_Tracker_Backend.Models.Enums
{
    public enum OtpChannel
    {
        EMAIL,
        SMS
    }
}
