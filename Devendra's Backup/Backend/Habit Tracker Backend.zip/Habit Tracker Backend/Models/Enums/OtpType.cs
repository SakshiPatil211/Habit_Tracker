﻿namespace Habit_Tracker_Backend.Models.Enums
{
    public enum OtpType
    {
        FORGOT_PASSWORD
    }
}
