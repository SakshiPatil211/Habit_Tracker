const Dashboard = () => {
  return <h1>Welcome to Dashboard</h1>;
};

export default Dashboard;
